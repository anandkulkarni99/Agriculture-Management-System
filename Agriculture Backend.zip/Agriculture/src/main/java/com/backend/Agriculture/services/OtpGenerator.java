package com.backend.Agriculture.services;


public interface OtpGenerator {

	String generateOTP();

}
